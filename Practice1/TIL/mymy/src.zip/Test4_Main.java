
public class Test4_Main {

	public static void main(String[] args) 
	{
	   Test4 t4=Test4.getInstance(80,90);
	}

}
