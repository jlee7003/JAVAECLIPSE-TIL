
public class Test6_Main {

	public static void main(String[] args) 
	{
		Test6 t6=new Test6();
		t6.input();
		t6.hap();
		
	}

}
