
public class Test2_Main {

	public static void main(String[] args) 
	{
       Test2 t2=new Test2();
       Test2 t22=new Test2(100);
       Test2 t222=new Test2(3,30);
       
       t2.random_gen();
       t22.random_gen();
       t222.random_gen();
	}

}
