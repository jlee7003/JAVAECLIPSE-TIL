
public class Test3_Main {

	public static void main(String[] args) 
	{
	   Test3 t3=new Test3();
	   
	   t3.average(90);
	   t3.average(80,70);
	   t3.average(90,80,70);
	   t3.average(80,60,80,70);
	}

}
