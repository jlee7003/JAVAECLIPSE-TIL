
public class Test7_Main {

	public static void main(String[] args) 
	{
	  Test7 t7=new Test7();
	  t7.input();
	  t7.hap();
	  t7.avg();
	  t7.chul();
	}

}
