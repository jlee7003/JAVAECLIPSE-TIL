
public class Test1_Main 
{
	public static void main(String[] args) 
	{
	   Test1 t1=new Test1(11,55);
	   
	   t1.hap();
	}
}
