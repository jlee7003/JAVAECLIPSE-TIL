
public class Test5_Main {

	public static void main(String[] args) 
	{
	  Test5 t5=new Test5();
	  
	  t5.input();
	  t5.hap();
	}

}
