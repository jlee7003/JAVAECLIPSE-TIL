package date603;

public class time 
{

	public static void main(String[] args) 
	{
		System.out.println(System.currentTimeMillis()*1/1000*1/60*1/24*1/31);
		System.out.println(System.getProperty("java.home"));
		System.out.println(System.getProperty("user.name"));

	}

}
