package date603;

import java.util.Date;

public class Return_main
{

	public static void main(String[] args)
	{
		Return r=new Return();
		
		//System.out.println(r.aaa());
		int a=r.aaa();
		//System.out.println(r.bbb());
		int[] aa=r.bbb();
		//System.out.println(r.ccc());
		Date tt=r.ccc();
		//����
	}

}
